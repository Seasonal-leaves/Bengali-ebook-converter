# OCR Benchmark

## Page 2 gold-standard fixture

The first benchmark uses a manually verified passage from page 2 of the `পেয়িং গেস্ট` test PDF.

`tests/fixtures/paying_guest/page_002_gold.txt` is the reference transcription. It is intentionally a small passage for the first iteration; we can expand it after the OCR engine is selected.

The existing PDF text layer is **not** treated as ground truth. It is useful for comparison, but it contains recognition and reading-order errors.

## Metrics

- **CER (Character Error Rate):** edit distance at character level divided by reference character count.
- **WER (Word Error Rate):** edit distance at whitespace-token level divided by reference word count.
- **Reading order:** reviewed separately because a low character error rate can still produce a poor ebook if blocks are returned in the wrong order.
- **Layout/structure:** reviewed separately for headings, columns, illustrations and decorative elements.

Lower CER/WER is better. We will not select an OCR engine on CER/WER alone; reading order and structure are first-class requirements.
