# Bengali Ebook Converter

A local, open-source pipeline for converting scanned Bengali/English books into reflowable ebooks using OCR and layout analysis.

> **Status:** v0.1 — OCR proof of concept. EPUB/Kindle generation is intentionally not implemented yet.

## Goals

- Bengali and English OCR for scanned PDFs
- Preserve illustrations and their position in the document structure
- Detect reading order in multi-column pages
- Detect chapters/headings
- Generate a navigable EPUB
- Generate a Kindle-compatible output from the canonical EPUB
- Preserve useful page anchors and internal links

## Pipeline

```text
PDF
 ↓
Page rendering
 ↓
Image preprocessing
 ↓
OCR
 ↓
Layout analysis
 ↓
Document IR
 ↓
EPUB
 ↓
Kindle-compatible output
```

## v0.1

The first milestone only renders pages and performs OCR. OCR results are saved as plain text plus structured TSV/JSON so that we can benchmark OCR separately from layout reconstruction.

### Example

```bash
ebook-converter ocr book.pdf --language ben+eng --dpi 300 --output output/book
```

The command creates:

```text
output/book/
├── pages/
│   ├── page_001.png
│   └── ...
├── ocr/
│   ├── page_001.txt
│   ├── page_001.tsv
│   └── ...
└── manifest.json
```

## Test fixture

`tests/fixtures/paying_guest/source.pdf` is a small scanned Bengali book used during development. It contains two-column text, chapter headings, decorative elements and illustrations, making it useful for layout/OCR testing.

## Development

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -e ".[dev]"
pytest
```

Tesseract OCR must also be installed with Bengali (`ben`) language data available.
