from __future__ import annotations

from pathlib import Path

import pytesseract
from PIL import Image


def recognize(image_path: Path, language: str = "ben+eng", psm: int = 3) -> tuple[str, str]:
    config = f"--psm {psm}"
    with Image.open(image_path) as image:
        text = pytesseract.image_to_string(image, lang=language, config=config)
        tsv = pytesseract.image_to_data(
            image,
            lang=language,
            config=config,
            output_type=pytesseract.Output.STRING,
        )
    return text, tsv
