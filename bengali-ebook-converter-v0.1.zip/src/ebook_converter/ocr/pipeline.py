from __future__ import annotations

import json
from pathlib import Path

from ..pdf.renderer import render_pdf
from .tesseract import recognize


def run_ocr(
    pdf_path: Path,
    output_dir: Path,
    *,
    language: str = "ben+eng",
    dpi: int = 300,
    psm: int = 3,
) -> None:
    pages_dir = output_dir / "pages"
    ocr_dir = output_dir / "ocr"
    pages = render_pdf(pdf_path, pages_dir, dpi=dpi)
    ocr_dir.mkdir(parents=True, exist_ok=True)

    manifest = {
        "source": str(pdf_path),
        "language": language,
        "dpi": dpi,
        "psm": psm,
        "pages": [],
    }

    for index, page_path in enumerate(pages, start=1):
        text_path = ocr_dir / f"page_{index:03d}.txt"
        tsv_path = ocr_dir / f"page_{index:03d}.tsv"
        text, tsv = recognize(page_path, language=language, psm=psm)
        text_path.write_text(text, encoding="utf-8")
        tsv_path.write_text(tsv, encoding="utf-8")
        manifest["pages"].append({
            "number": index,
            "image": str(page_path.relative_to(output_dir)),
            "text": str(text_path.relative_to(output_dir)),
            "tsv": str(tsv_path.relative_to(output_dir)),
        })
        print(f"[{index:03d}/{len(pages):03d}] OCR complete")

    (output_dir / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
