from __future__ import annotations

import argparse
from pathlib import Path

from .benchmark import benchmark
from .ocr.pipeline import run_ocr


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ebook-converter",
        description="OCR and convert scanned books into reflowable ebooks.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    bench = subparsers.add_parser("benchmark", help="Compare OCR output with a gold-standard transcription.")
    bench.add_argument("reference", type=Path)
    bench.add_argument("hypothesis", type=Path)

    ocr = subparsers.add_parser("ocr", help="Render a PDF and run OCR on each page.")
    ocr.add_argument("pdf", type=Path)
    ocr.add_argument("--language", default="ben+eng")
    ocr.add_argument("--dpi", type=int, default=300)
    ocr.add_argument("--output", type=Path, default=Path("output/ocr"))
    ocr.add_argument("--psm", type=int, default=3, help="Tesseract page segmentation mode.")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.command == "benchmark":
        result = benchmark(args.reference, args.hypothesis)
        print(f"CER: {result["cer"]:.2%}")
        print(f"WER: {result["wer"]:.2%}")
    elif args.command == "ocr":
        run_ocr(args.pdf, args.output, language=args.language, dpi=args.dpi, psm=args.psm)
