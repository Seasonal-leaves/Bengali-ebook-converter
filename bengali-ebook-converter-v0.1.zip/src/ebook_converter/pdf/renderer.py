from __future__ import annotations

from pathlib import Path

import fitz


def render_pdf(pdf_path: Path, output_dir: Path, dpi: int = 300) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    rendered: list[Path] = []
    scale = dpi / 72.0
    matrix = fitz.Matrix(scale, scale)

    with fitz.open(pdf_path) as document:
        for page_index, page in enumerate(document):
            output = output_dir / f"page_{page_index + 1:03d}.png"
            if not output.exists():
                pixmap = page.get_pixmap(matrix=matrix, alpha=False)
                pixmap.save(output)
            rendered.append(output)

    return rendered
