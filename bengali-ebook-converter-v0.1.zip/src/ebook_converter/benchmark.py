from __future__ import annotations

import re
from pathlib import Path


def normalize(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{2,}", "\n", text)
    return text.strip()


def levenshtein(a: str, b: str) -> int:
    previous = list(range(len(b) + 1))
    for i, ca in enumerate(a, start=1):
        current = [i]
        for j, cb in enumerate(b, start=1):
            current.append(min(
                current[-1] + 1,
                previous[j] + 1,
                previous[j - 1] + (ca != cb),
            ))
        previous = current
    return previous[-1]


def cer(reference: str, hypothesis: str) -> float:
    reference = normalize(reference)
    hypothesis = normalize(hypothesis)
    if not reference:
        return 0.0 if not hypothesis else 1.0
    return levenshtein(reference, hypothesis) / len(reference)


def wer(reference: str, hypothesis: str) -> float:
    ref = normalize(reference).split()
    hyp = normalize(hypothesis).split()
    if not ref:
        return 0.0 if not hyp else 1.0
    return levenshtein(ref, hyp) / len(ref)


def benchmark(reference_path: Path, hypothesis_path: Path) -> dict[str, float]:
    reference = reference_path.read_text(encoding="utf-8")
    hypothesis = hypothesis_path.read_text(encoding="utf-8")
    return {"cer": cer(reference, hypothesis), "wer": wer(reference, hypothesis)}
