from pathlib import Path

from ebook_converter.pdf.renderer import render_pdf


def test_render_first_page(tmp_path: Path) -> None:
    source = Path("tests/fixtures/paying_guest/source.pdf")
    pages = render_pdf(source, tmp_path / "pages", dpi=72)
    assert len(pages) == 17
    assert pages[0].exists()
