from ebook_converter.benchmark import cer, wer


def test_identical_text_has_zero_error() -> None:
    text = "তাহলে তুই কি সাঁইথিয়াতেই জয়েন করবি বলে ঠিক করলি?"
    assert cer(text, text) == 0
    assert wer(text, text) == 0


def test_errors_are_positive() -> None:
    reference = "তাহলে তুই কি সাঁইথিয়াতেই জয়েন করবি বলে ঠিক করলি?"
    hypothesis = "হলে তুই কি সাইথিয়াতেই জয়েন করবি বলে ঠিক করলি?"
    assert cer(reference, hypothesis) > 0
    assert wer(reference, hypothesis) > 0
