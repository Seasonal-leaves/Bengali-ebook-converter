from pathlib import Path

from ebook_converter.ocr.tesseract import recognize
from ebook_converter.pdf.renderer import render_pdf


def test_bengali_ocr_returns_text(tmp_path: Path) -> None:
    source = Path("tests/fixtures/paying_guest/source.pdf")
    pages = render_pdf(source, tmp_path / "pages", dpi=150)
    text, _ = recognize(pages[1], language="ben+eng", psm=3)
    assert text.strip()
